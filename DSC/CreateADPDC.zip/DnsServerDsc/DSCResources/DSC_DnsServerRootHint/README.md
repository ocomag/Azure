# Description

The DnsServerRootHint DSC resource manages root hints on a Domain Name System (DNS) server.
