configuration CreateADPDC 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration, xActiveDirectory, xNetworking, xStorage

    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature DNS { 
            Ensure = "Present" 
            Name   = "DNS"		
        }

        WindowsFeature ADDSInstall { 
            Ensure = "Present" 
            Name   = "AD-Domain-Services" 
            DependsOn = "[WindowsFeature]DNS"
        } 

        WindowsFeature ADDSTools {
            Ensure = "Present"
            Name = "RSAT-AD-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = (Get-NetAdapter | Where-Object { $_.Status -eq 'Up' }).Name
            AddressFamily  = 'IPv4'
            DependsOn      = "[WindowsFeature]DNS"
        }

        xADDomain FirstDS 
        {
            DomainName                    = $DomainName
            DomainAdministratorCredential = $AdminCreds
            SafemodeAdministratorPassword = $AdminCreds
            DatabasePath                  = "C:\NTDS"
            LogPath                       = "C:\NTDS"
            SysvolPath                    = "C:\SYSVOL"
            DependsOn                     = @("[WindowsFeature]ADDSInstall", "[xDNS]DnsServerAddress")
        } 
    }
}

CreateADPDC
